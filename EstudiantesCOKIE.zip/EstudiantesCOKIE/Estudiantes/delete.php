<?php

require_once '../helper/utility.php';
require_once 'estudiantes.php';
require_once '../service/IService.php';
require_once 'estudianteServiceCookie.php';

$service = new EstudianteServiceCookie();

$isContainId = isset($_GET['id']);

if($isContainId){

    $estudianteId = $_GET['id'];

    $service->Delete($estudianteId);

}

header("Location: ../index.php");
exit();

?>