<?php

class EstudianteServiceCookie implements IServiceBase{
    
    private $utility;
    private $cookieName;

    public function __construct(){

        $this->utility = new Utility();
        $this->cookieName= 'estudiantes';
    }

    public function GetList(){

        $listadoEstudiantes = array();

        if(isset($_COOKIE[$this->cookieName])){

            $listadoEstudiantesDecode = json_decode($_COOKIE[$this->cookieName], false);

            foreach($listadoEstudiantesDecode as $elementDecode){
                $element = new estudiantes();
                $element->set($elementDecode);

                array_push($listadoEstudiantes, $element);
            }

        } 
        else{
            setcookie($this->cookieName, json_encode($listadoEstudiantes), $this->utility->GetCookieTime(),"/"); 
        }

        return $listadoEstudiantes;


    }

    public function GetById($id){
        $listadoEstudiantes = $this->GetList();
        $estudiante = $this->utility->searchProperty($listadoEstudiantes, 'id', $id)[0];
        return $estudiante;
    }

    public function Add($entity){
        $listadoEstudiantes = $this->GetList();
        $estudianteId = 1;

        if(!empty($listadoEstudiantes)){
            $lastEstudiante = $this->utility->getLastElement($listadoEstudiantes);
            $estudianteId = $lastEstudiante->id + 1;
        }

        $entity->id = $estudianteId;
        $entity->profilePhoto = "";

        if(isset($_FILES['profilePhoto'])){

            $photoFile = $_FILES['profilePhoto'];

            if($photoFile['error'] == 4){
                $entity->profilePhoto = "";
            }

            else{

            $typeReplace = str_replace("image/","", $photoFile ['type']);
            $type =  $photoFile ['type'];
            $size =  $photoFile ['size'];
            $name =  $estudianteId. '.'. $typeReplace;
            $tmpname =  $photoFile ['tmp_name'];

            $success = $this->utility->UploadImage('../Asset/img/estudiantes/',$name, $tmpname, $type, $size);

            if($success){
                $entity->profilePhoto = $name;

            }

            
            
            }

        }

        array_push($listadoEstudiantes, $entity);

        setcookie($this->cookieName, json_encode($listadoEstudiantes), $this->utility->GetCookieTime(),"/"); 
    }

    public function Update($id, $entity){
        $element = $this->GetById($id);
        $listadoEstudiantes = $this->GetList();

        $elementIndex = $this->utility->getIndexElement($listadoEstudiantes,'id',$id);

        if(isset($_FILES['profilePhoto'])){

            $photoFile = $_FILES['profilePhoto'];

            if($photoFile['error'] == 4){
                $entity->profilePhoto = $element->profilePhoto;
            }

            else{
                
            $typeReplace = str_replace("image/","",$photoFile ['type']);
            $type = $photoFile ['type'];
            $size = $photoFile ['size'];
            $name =  $id. '.'. $typeReplace;
            $tmpname = $photoFile ['tmp_name'];

            $success = $this->utility->UploadImage('../Asset/img/estudiantes/',$name, $tmpname, $type, $size);

            if($success){
                $entity->profilePhoto = $name;
            }

            }
            
        }

        $listadoEstudiantes[$elementIndex] = $entity;

        setcookie($this->cookieName, json_encode($listadoEstudiantes), $this->utility->GetCookieTime(),"/");
    }

    public function Delete($id){
        $listadoEstudiantes = $this->GetList();
        $elementIndex = $this->utility->getIndexElement($listadoEstudiantes,'id',$id);

        unset($listadoEstudiantes[$elementIndex]);

        $listadoEstudiantes = array_values($listadoEstudiantes);

        setcookie($this->cookieName, json_encode($listadoEstudiantes), $this->utility->GetCookieTime(),"/");
    }
}

?>