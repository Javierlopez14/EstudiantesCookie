<?php 

class Utility {

    public $estado = [1 => "Activo", 2 =>"Inactivo"];

    public $carrera = [1=> "Selecione una Carrera",2 => 'Redes',3 => "Software",4 => "Multimedia",
                5 => "Mecatronica",6 => "Seguridad Informatica"];

    public function getLastElement($list){
        $countList = count($list);
        $lastElement = $list[$counList - 1];

        return lastElement;
    }

    public function searchProperty($list, $property, $value){
        $filter = [];

        foreach($list as $item){
            if($item->$property == $value){
                array_push($filter, $item);
            }
        }

        return $filter;
    }

    public function GetCookieTime(){
        return time() + 60*60*24*30; 
    }

    public function getIndexElement($list, $property, $value){
        $index = 0;

        foreach($list as $key => $item){
            if($item->$property == $value){
               $index = $key;
            }
        }

        return $index;
    }

    public function UploadImage($directory, $name, $tmpFile, $type, $size){
        $isSuccess = false;

        if(($type == "image/gif")
            || ($type == "image/jpeg")
            || ($type == "image/png")
            || ($type == "image/jpg")
            || ($type == "image/JPG")
            || ($type == "image/pjpeg") && ($Size < 1000000))
            {
                if(!file_exists($directory)){

                    mkdir($directory,0777,true);

                    if(file_exists($directory)){
                        
                        $this->UploadFile($directory . $name, $tmpFile);
                        $isSuccess = true;
                    }

                }
                else{
                    $this->UploadFile($directory . $name, $tmpFile);
                    $isSuccess = true;
                }
        }

        else{
            $isSuccess = false;
        }

        return $isSuccess;
    }

    private function UploadFile($name, $tmpFile){

        if(file_exists($name)){
            unlink($name);
        }

        move_uploaded_file($tmpFile, $name);
    }

}

    

?>